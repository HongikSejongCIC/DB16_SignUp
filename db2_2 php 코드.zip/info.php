<? //학생의 회원정보를 입력할 수 있는 페이지
session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php
        include "dbInfo.php";

        $id = $_SESSION['userid'];
        $passwd = $_SESSION['passwd'];
        ?>
    </title>
</head>

<body>
<?php
$query = "SELECT * FROM Student WHERE st_id = '$id'";
$result = mysqli_query($conn, $query);
$rows = mysqli_num_rows($result);
//if (!$rows) {
    $query = "INSERT INTO Student (st_id, passwd) VALUES ('$id','$passwd')";
    $result = mysqli_query($conn, $query);

    ?>
    <form method="POST" action="insertinfo.php" enctype="multipart/form-data">
        <h1>회원정보입력</h1>
        <table border="1">
            <tr>
                <td>ID :</td>
                <td><input type="text" name="id" value="<?= $id ?>" readonly></td>
            </tr>
            <tr>
                <td>비밀번호 :</td>
                <td><input type="text" name="passwd" value="<?= $passwd ?>"></td>
            </tr>
            <tr>
                <td>이름 :</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>생년월일 :</td>
                <td><input type="text" size="45" name="birth"></td>
            </tr>
            <tr>
                <td>학년 :</td>
                <td><input type="text" size="45" name="grade"></td>
            </tr>
            <tr>
                <td>핸드폰번호 :</td>
                <td><input type="text" name="phone"></td>
            </tr>
            <tr>
                <td>email 주소 :</td>
                <td><input type="text" size="45" name="email"></td>
            </tr>
            <tr>
                <td colspan="2" align="center"></td>
                <input type="submit" value="제출">&nbsp;
                <input tpye="reset" value="초기화">
            </tr>
        </table>
    </form>
<?php
//}else{
?>
<!--
    <script>
        alert("이미 존재하는 아이디입니다.");
        history.back();
    </script>
    -->
    <?php
//}
?>
</body>
</html>