<? session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php

include "dbInfo.php";
$id = $_POST['id'];
$passwd = $_POST['passwd'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$birth = $_POST['birth'];
$grade = $_POST['grade'];
$email = $_POST['email'];

$query = "UPDATE Student SET passwd='$passwd', name='$name', phone='$phone', birth='$birth', grade='$grade', email='$email' WHERE st_id='$id'";
mysqli_query($conn, $query);
?>
<table border="1">
    <?php
    $query = "select * from Student";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_array($result)) {
        $id = $row['id'];
        $name = $row['name'];
        $phone = $row['phone'];

    }
    ?>
    <tr>
        <td><?= $id ?></td>
        <td><?= $passwd ?></td>
        <td><?= $phone ?></td>
        <td><?= $name ?></td>
        <td><?= $email ?></td>
        <td><?= $grade ?></td>
    </tr>
</table>
</body>
</html>


