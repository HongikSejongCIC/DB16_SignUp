<? 
//로그인 정보를 데이터베이스의 데이터와 비교하여 맞는지 확인
session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
include "dbInfo.php";

$id = $_POST['st_id'];
$passwd = $_POST['passwd'];
$query = "select * from Student where st_id='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);
$userid = $row['st_id'];
$userpasswd = $row['passwd'];
if ($userid == "") {
 ?>
    <script>
        alert("존재하지 않는 아이디입니다.");
        history.back();
    </script>
<?php

}else{
if ($passwd != $userpasswd) {

?>
    <script>
        alert("잘못된 패스워드입니다.");
        history.back();
    </script>
<?php
}else{
$query = "select * from Student where st_id='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);

$username = $row['name'];
$_SESSION['userid']=$id;
$_SESSION['passwd']=$passwd;
$_SESSION['is_logged']='YES';
?>
    <script>
        var name = '<?= $username ?>';
        alert("안녕하세요!");
    </script>
    <p><a href="membership.php">회원 페이지</a></p>
    <p><a href="info.php">회원정보 입력 페이지</a></p>
    <?php
}
}
?>
</body>
</html>
