<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"
    <title>
    </title>
    <?php
	//학생이 학생의 정보를 입력하는 페이지


    include "dbInfo.php";

    $id = $_POST['id'];
    $passwd =$_POST['passwd'];
    ?>
</head>
<body>
<?php


$query = "SELECT * FROM Student where id ='$id'";
$result = mysqli_query($conn, $query);
$rows = mysqli_num_rows($result);
if(!$rows){
    $query = "INSERT INTO Student(id, passwd) VALUES ('$id','$passwd')";
    $result = mysqli_query($conn, $query);
}
?>

<form method="POST" action="insertInfo.php" enctype="multipart/form-data">
    <h1>회원정보입력</h1>
    <talbe border="1">
        <tr>
            <td>ID :</td>
            <td><input type="text" name="id" values="<?=$id?> readonly"></td>
        </tr>
        <tr>
            <td>ID :</td>
            <td><input type="text" name="id" values="<?=$id?> readonly"></td>
        </tr>
        <tr>
            <td>ID :</td>
            <td><input type="text" name="id" values="<?=$id?> readonly"></td>
        </tr>
        <tr>
            <td>ID :</td>
            <td><input type="text" name="id" values="<?=$id?> readonly"></td>
        </tr>
    </talbe>
</form>
</body>
</html>
