<?	//������û�� ������ öȸ�� �� �ִ� ������ 
session_start(); 
include "dbInfo.php";?>

<head>
    <style type="text/css">
        #wrapper {
            width: 1500px;
            height: 2100px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #828282;
        }

        #header {
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #828282;
        }

        #aside_left {
            margin: 0 20px 20px 0;
            padding: 20px;
            width: 80%;
            float: left;
            border: 1px solid #828282;
        }

        #section {
            margin-bottom: 20px;
            padding: 20px;
            width: 70%;
            float:left;
            border: 1px solid #828282;
        }

        #aside_right {
            margin-bottom: 20px;
            padding: 20px;
            width: 80%;
            float:left;
            border: 1px solid #828282;
        }

        #aside_wrapper{
            margin:0 auto;
            padding:20px;
            witdth: 10%;
            border: 1px solid #828282;
            float:left;
        }
    </style>
</head>

<body>
<div id="wrapper">
    <div id="header">
        <h1>������û ������</h1>
    </div>
    <div id="aside_wrapper">
        <div id="aside_left">
          
            <ul>
                <li><a href="allSubject.php">��ü���񺸱�</a></li>
                <li><a href="deleteSubject.php">����öȸ�ϱ�</a></li>
                <li><a href="searchSubject.php">�󼼰˻��ϱ�</a></li>

            </ul>
        </div>

        <div id="aside_right">
        
					
<?
	$idStudent = $_SESSION['userid'];

	$result4 = mysqli_query($conn, "delete from signuptable where idStudent='$idStudent';");
	$result5 = mysqli_query($conn, "insert into signuptable(
									time1, a1,b1,c1,d1,e1,
									time2, a2,b2,c2,d2,e2,
									time3, a3,b3,c3,d3,e3,
									time4, a4,b4,c4,d4,e4,
									time5, a5,b5,c5,d5,e5,
									time6, a6,b6,c6,d6,e6,
									time7, a7,b7,c7,d7,e7,
									time8, a8,b8,c8,d8,e8,
									time9, a9,b9,c9,d9,e9, idStudent) values (
									1, null, null, null, null, null,
									2, null, null, null, null, null,
									3, null, null, null, null, null,
									4, null, null, null, null, null,
									5, null, null, null, null, null,
									6, null, null, null, null, null,
									7, null, null, null, null, null,
									8, null, null, null, null, null,
									9, null, null, null, null, null, '$idStudent');");

		$result2 = mysqli_query($conn, "select * from Register, Subject where st_id='$idStudent' and Register.sb_id=Subject.sb_id");
	while($row2= mysqli_fetch_array($result2)) {
	$aa = $row2['time1'];
	
	$bb = $row2['time2'];

	$cc = $row2['time3'];
	
	$subjectName = $row2['name'];
	//$sb_id = $row2["sb_id"];
	
	
	$result3 = mysqli_query($conn, "update signuptable set $aa ='$subjectName' where idStudent='$idStudent';");
	$result3 = mysqli_query($conn, "update signuptable set $bb ='$subjectName' where idStudent='$idStudent';");
	$result3 = mysqli_query($conn, "update signuptable set $cc ='$subjectName' where idStudent='$idStudent';");
	}

	$result = mysqli_query($conn, "select * from signuptable where idStudent='$idStudent'");

	$row = mysqli_fetch_array($result);
	
?>

<h1><font size="3"> �й� : <? echo($idStudent)?></font></h1>

<table border ="1" size="100%">
<tr>
	<td width = "50">�ð�</td>
	<td width = "100">��</td>
	<td width = "100">ȭ</td>
	<td width = "100">��</td>
	<td width = "100">��</td>
	<td width = "100">��</td>
</tr>
<tr>
	<td><? echo($row["time1"]); ?></td>
	<td><? echo($row["a1"]); ?></td>
	<td><? echo($row["b1"]); ?></td>
	<td><? echo($row["c1"]); ?></td>
	<td><? echo($row["d1"]); ?></td>
	<td><? echo($row["e1"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time2"]); ?></td>
	<td><? echo($row["a2"]); ?></td>
	<td><? echo($row["b2"]); ?></td>
	<td><? echo($row["c2"]); ?></td>
	<td><? echo($row["d2"]); ?></td>
	<td><? echo($row["e2"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time3"]); ?></td>
	<td><? echo($row["a3"]); ?></td>
	<td><? echo($row["b3"]); ?></td>
	<td><? echo($row["c3"]); ?></td>
	<td><? echo($row["d3"]); ?></td>
	<td><? echo($row["e3"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time4"]); ?></td>
	<td><? echo($row["a4"]); ?></td>
	<td><? echo($row["b4"]); ?></td>
	<td><? echo($row["c4"]); ?></td>
	<td><? echo($row["d4"]); ?></td>
	<td><? echo($row["e4"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time5"]); ?></td>
	<td><? echo($row["a5"]); ?></td>
	<td><? echo($row["b5"]); ?></td>
	<td><? echo($row["c5"]); ?></td>
	<td><? echo($row["d5"]); ?></td>
	<td><? echo($row["e5"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time6"]); ?></td>
	<td><? echo($row["a6"]); ?></td>
	<td><? echo($row["b6"]); ?></td>
	<td><? echo($row["c6"]); ?></td>
	<td><? echo($row["d6"]); ?></td>
	<td><? echo($row["e6"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time7"]); ?></td>
	<td><? echo($row["a7"]); ?></td>
	<td><? echo($row["b7"]); ?></td>
	<td><? echo($row["c7"]); ?></td>
	<td><? echo($row["d7"]); ?></td>
	<td><? echo($row["e7"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time8"]); ?></td>
	<td><? echo($row["a8"]); ?></td>
	<td><? echo($row["b8"]); ?></td>
	<td><? echo($row["c8"]); ?></td>
	<td><? echo($row["d8"]); ?></td>
	<td><? echo($row["e8"]); ?></td>
</tr>
<tr>
	<td><? echo($row["time9"]); ?></td>
	<td><? echo($row["a9"]); ?></td>
	<td><? echo($row["b9"]); ?></td>
	<td><? echo($row["c9"]); ?></td>
	<td><? echo($row["d9"]); ?></td>
	<td><? echo($row["e9"]); ?></td>
</tr>

</table>
        </div>
    </div>
    <div id="section">
        <h2>����öȸ���ɰ���</h2>
        <form method="POST" action="cancel.php">
            <table style="text-align: center">
                <tr>
                    <td>�м���ȣ</td>
                    <td>�̼�����</td>
                    <td>����</td>
                    <td>�����̸�</td>
                    <td>�����̸�</td>
                    <td>����</td>
                    <td>�ּ��ο�</td>
                    <td>�����ο�</td>
                    <td>�ִ��ο�</td>
                    <td>�ð�</td>
                    <td>���ǽ�</td>
                    <td>ķ�۽�����</td>
                    <td>���</td>
                </tr>
                <?php
				include "dbInfo.php";
                $st_id=$_SESSION['userid'];
	
				$query = "select * from register, subject where register.sb_id=subject.sb_id and st_id='$st_id';";
                //$query = "select s.* from Register as r, Subject as s where s.sb_id=r.sb_id and r.st_id='$st_id';";
                $result = mysqli_query($conn, $query);

                while ($row = mysqli_fetch_array($result)) {
                    $sb_id = $row['sb_id'];
                    $division = $row['division'];
                    $area = $row['area'];
                    $pr_id = $row['pr_id'];
                    $name = $row['name'];
                    $credits = $row['credits'];
                    $minPerson = $row['minPerson'];
                    $regPerson = $row['regPerson'];
                    $totPerson = $row['totPerson'];
                    $time = $row['time'];
                    $classroom = $row['classroom'];
                    $campus = $row['campus'];
                    $note = $row['note'];
                    ?>
                    <tr>
                        <td><?= $sb_id ?></td>
                        <td><?= $division ?></td>
                        <td><?= $area ?></td>
                        <td><?= $pr_id ?></td>
                        <td><?= $name ?></td>
                        <td><?= $credits ?></td>
                        <td><?= $minPerson ?></td>
                        <td><?= $regPerson ?></td>
                        <td><?= $totPerson ?></td>
                        <td><?= $time ?></td>
                        <td><?= $classroom ?></td>
                        <td><?= $campus ?></td>
                        <td><?= $note ?></td>
                        <td><input type="checkbox" name="checkedSubject[]" value="<?=$sb_id ?>"></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="14" style="text-align:right">
                        <input type="submit" value="����öȸ">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>


</body>
</html>

