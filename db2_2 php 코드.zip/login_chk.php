<?php
//로그인을 했을때 처리하는 페이지
include "dbInfo.php";

$query = "SELECT passwd FROM Student where st_id='{$_POST['st_id']}'";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_array($result);

if(!empty($row) && ($row['passwd'] == $_POST['passwd'])){
    echo "로그인 되었습니다. {$_POST['userid']} 님! <br>";
}
else{
    echo "올바른 인증정보를 넣어주세요!";
    exit;
}
?>