<?php session_start();?>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
</head>

<?php
include "dbInfo.php";

$st_id = $_SESSION['userid'];

foreach ($_POST['checkedSubject'] as $value) {
    $sb_id = $value;

    $query = "delete from Register where st_id='$st_id' AND sb_id='$sb_id'";
    $result = mysqli_query($conn, $query);
}
?>
<body>
<h2>수강철회완료</h2>
<table border="1">
    <?php
    $query = "SELECT * from Register where st_id='$st_id'";
    $result = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?= $row['st_id'] ?></td>
            <td><?= $row['sb_id'] ?></td>
        </tr>
        <?php
    }
    ?>
</table>
</body>
</html>
