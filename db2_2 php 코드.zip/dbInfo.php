<?php
//연동된 mysql database에 대한 정보
$conn =mysqli_connect("localhost", "root", "apmsetup", "test");
?>

