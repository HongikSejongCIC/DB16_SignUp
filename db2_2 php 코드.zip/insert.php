<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<?php
//로그인페이지에서 로그인 했을때 처리하는 부분
include "dbInfo.php";
$id = $_POST['id'];
$passwd = $_POST['passwd'];
$job = $_POST['job'];
if ($job == "학생") {
    $query = "INSERT INTO Student (st_id, passwd) VALUES ('$id','$passwd')";
    mysqli_query($conn, $query);

} else if ($job == "교수") {
    $query = "INSERT INTO Professor (pr_id, passwd) VALUES ('$id','$passwd')";
    mysqli_query($conn, $query);
}
?>

<table border="1">

    <?php
    $query = "SELECT * FROM Student";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_array($result)) {
        $id = $row['id'];
        $passwd = $row['passwd'];

    }
    ?>
    <tr>
        <td><?= $id ?></td>
        <td><?= $passwd ?></td>
    </tr>
</table>
</body>
</html>
